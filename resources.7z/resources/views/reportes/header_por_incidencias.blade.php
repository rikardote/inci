<!doctype html>
<html>
<head>

</head>
<body>
<table border="0" cellpadding="12" cellspacing="0" style="width:850px;">
	<tbody>
		<tr>
			<td><img alt="" src="images/60issste.png" style="width: 400px; height: 108px;" /></td>
			<td align='right'>
			<p><h3><strong>REPRESENTACION ESTATAL BAJA CALIFORNIA</strong></h3></p>

			<p><h3><strong>SUBDELEGACION DE ADMINISTRACION</strong></h3></p>

			<p><h4><strong>DEPARTAMENTO DE RECURSOS HUMANOS</strong></h4></p>

			</td>
		</tr>


		<table border="0" cellpadding="1" cellspacing="1" style="width:500px;">

			<tbody>
				<tr>
					<p><td style="width: 100%; background-color: rgb(102, 102, 102);"><span style="color:#FFFFFF;">REPORTE POR INCIDENCIA</span></td></p>
				</tr>
			</tbody>
		</table>



	</tbody>

</table>
<span style="font-size:12px;">PERIODO DE FECHAS DEL: <strong>{{$fecha_inicio}} AL {{$fecha_final}}</strong></span>
<hr>
</body>
</html>
