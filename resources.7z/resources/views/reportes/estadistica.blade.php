<table class="table table-bordered">
	<tr align="center">
		<td>01</td>
		<td>02</td>
		<td>03</td>
		<td>04</td>
		<td>08</td>
		<td>09</td>
		<td>10</td>
		<td>14</td>
		<td>15</td>
		<td>17</td>
		<td>30</td>
		<td>40</td>
		<td>41</td>
		<td>42</td>
		<td>46</td>
		<td>47</td>
		<td>48</td>
		<td>49</td>
		<td>51</td>
		<td>53</td>
		<td>54</td>
		<td>55</td>
		<td>60</td>
		<td>61</td>
		<td>62</td>
		<td>63</td>
		<td>94</td>
		<td>100</td>
        <td>Total</td>
		
	</tr>

	<tr align="center">
		<td><span class="badge">{{ $codigo_01->count ? $codigo_01->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_02->count ? $codigo_02->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_03->count ? $codigo_03->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_04->count ? $codigo_04->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_08->count ? $codigo_08->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_09->count ? $codigo_09->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_10->count ? $codigo_10->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_14->count ? $codigo_14->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_15->count ? $codigo_15->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_17->count ? $codigo_17->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_30->count ? $codigo_30->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_40->count ? $codigo_40->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_41->count ? $codigo_41->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_42->count ? $codigo_42->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_46->count ? $codigo_46->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_47->count ? $codigo_47->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_48->count ? $codigo_48->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_49->count ? $codigo_49->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_51->count ? $codigo_51->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_53->count ? $codigo_53->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_54->count ? $codigo_54->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_55->count ? $codigo_55->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_60->count ? $codigo_60->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_61->count ? $codigo_61->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_62->count ? $codigo_62->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_63->count ? $codigo_63->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_94->count ? $codigo_94->count:0}}</span></td>
		<td><span class="badge">{{ $codigo_100->count ? $codigo_100->count:0}}</span></td>
        <td><span class="badge">{{ 
				$codigo_01->count+
				$codigo_02->count+
				$codigo_03->count+
				$codigo_04->count+
        		$codigo_08->count+
        		$codigo_09->count+
        		$codigo_10->count+
        		$codigo_14->count+
        		$codigo_15->count+
        		$codigo_17->count+
        		$codigo_40->count+
        		$codigo_41->count+
        		$codigo_42->count+
        		$codigo_46->count+
        		$codigo_47->count+
        		$codigo_48->count+
        		$codigo_49->count+
        		$codigo_51->count+
        		$codigo_53->count+
        		$codigo_54->count+
        		$codigo_55->count+
        		$codigo_60->count+
        		$codigo_61->count+
        		$codigo_62->count+
        		$codigo_63->count+
        		$codigo_94->count+
        		$codigo_100->count }}
            </span>
        </td>
		
	</tr>
</table>