@extends('layout.main')

@section('title', $title)
 
@section('content')
   
    @include('reportes.vacaciones.searchEmpleado')
    
@endsection