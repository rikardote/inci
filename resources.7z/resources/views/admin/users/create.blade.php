{!! Form::open(['route' => 'users.store', 'method' => 'POST']) !!}
	@include('admin.users.create_form')
{!! Form::close() !!}

