	{!! Form::open(['route' => 'codigosdeincidencias.store', 'method' => 'POST']) !!}
		
	@include('admin.codigosdeincidencias._form')

	{!! Form::close() !!}


