<style>
  article { display: block; text-align: justify; width: 650px; margin: 0 auto; }
  h1 { color: #dc8100; text-decoration: none; }
  a:hover { color: #333; text-decoration: none; }
</style>

<article>
    <img src="{{ asset('images/manto.jpg') }}"></img> 

    <h1>En mantenimiento...</h1>
    <div>
        <p>Una disculpa por el incoveniente pero estamos realizando tareas de mantenimiento en este momento. Si necesitas apoyo marca a la extension 53033 en el Area de incidencias, de otra forma el sistema regresara pronto</p>
        <p>&mdash; Departamento de Recursos Humanos</p>
    </div>
</article>

