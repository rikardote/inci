<div id="msj-success" class=" alert-dismissible" role="alert" style="display:none">
     <strong>Incidencia Agregada Correctamente</strong>
</div>
<div id="msj-delete" class=" alert-dismissible" role="alert" style="display:none">
     <strong>Incidencia Eliminada Correctamente</strong>
     
</div>
