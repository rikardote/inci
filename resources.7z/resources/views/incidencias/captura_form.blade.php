<form method="POST" action="#" accept-charset="UTF-8" id="miFormulario"> 
        @include('incidencias._form')
        

 {!! Form::close() !!}

